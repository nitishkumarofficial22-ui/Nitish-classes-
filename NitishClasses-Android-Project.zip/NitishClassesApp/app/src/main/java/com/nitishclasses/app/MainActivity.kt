package com.nitishclasses.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Gold = Color(0xFFF4C430)
private val Black = Color(0xFF0A0A0A)
private val Card = Color(0xFF171717)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { NitishClassesApp() } }
}

@Composable fun NitishClassesApp() {
    var tab by remember { mutableIntStateOf(0) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Black, surface = Card, onPrimary = Black)) {
        Scaffold(containerColor = Black, bottomBar = {
            NavigationBar(containerColor = Color(0xFF101010)) {
                listOf(Icons.Default.Home to "Home", Icons.Default.MenuBook to "Courses", Icons.Default.Assignment to "Tests", Icons.Default.Person to "Profile").forEachIndexed { i, pair ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(pair.first, null) }, label = { Text(pair.second) })
                }
            }
        }) { pad -> Box(Modifier.padding(pad)) { when(tab) { 0 -> Home(); 1 -> Courses(); 2 -> Tests(); else -> Profile() } } }
    }
}

@Composable fun Header(title: String, subtitle: String? = null) { Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(title, fontSize=26.sp, fontWeight=FontWeight.Bold); subtitle?.let { Text(it, color=Color.LightGray) } }; Icon(Icons.Default.Notifications, null, tint=Gold) } }

@Composable fun Home() { LazyColumn(contentPadding=PaddingValues(bottom=24.dp)) {
    item { Header("Nitish Classes", "Dream • Learn • Grow") }
    item { Card(Modifier.padding(horizontal=16.dp).fillMaxWidth(), shape=RoundedCornerShape(20.dp)) { Column(Modifier.padding(18.dp)) { Text("Welcome, Student!", fontSize=21.sp, fontWeight=FontWeight.Bold); Text("Classes 9th – 12th", color=Gold); Spacer(Modifier.height(12.dp)); Button(onClick={}, colors=ButtonDefaults.buttonColors(containerColor=Gold, contentColor=Black)) { Text("Explore Courses") } } } }
    item { Text("Quick Access", fontSize=20.sp, fontWeight=FontWeight.Bold, modifier=Modifier.padding(18.dp,24.dp,18.dp,10.dp)) }
    item { Row(Modifier.padding(horizontal=12.dp), horizontalArrangement=Arrangement.spacedBy(10.dp)) { Quick(Icons.Default.PlayCircle, "Live Classes"); Quick(Icons.Default.PictureAsPdf, "Notes"); Quick(Icons.Default.Quiz, "Tests") } }
    item { Text("Our Classes", fontSize=20.sp, fontWeight=FontWeight.Bold, modifier=Modifier.padding(18.dp,24.dp,18.dp,10.dp)) }
    items(listOf("Class 9th","Class 10th","Class 11th","Class 12th")) { ClassCard(it) }
    item { Image(painterResource(R.drawable.nitish_brand), null, Modifier.fillMaxWidth().padding(16.dp).height(240.dp), contentScale=ContentScale.Crop) }
} }

@Composable fun Quick(icon: androidx.compose.ui.graphics.vector.ImageVector, label:String) { Card(Modifier.width(112.dp).height(100.dp), shape=RoundedCornerShape(16.dp)) { Column(Modifier.fillMaxSize().padding(10.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) { Icon(icon,null,tint=Gold); Text(label,fontSize=12.sp) } } }
@Composable fun ClassCard(name:String) { Card(Modifier.fillMaxWidth().padding(horizontal=16.dp, vertical=6.dp).clickable{}, shape=RoundedCornerShape(16.dp)) { Row(Modifier.padding(16.dp), verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.School,null,tint=Gold); Spacer(Modifier.width(14.dp)); Column { Text(name,fontWeight=FontWeight.Bold); Text("Physics • Chemistry • Maths • Biology", color=Color.LightGray, fontSize=12.sp) }; Spacer(Modifier.weight(1f)); Icon(Icons.Default.ChevronRight,null) } } }

@Composable fun Courses() { LazyColumn { item { Header("Courses","Choose your class") }; items(listOf("Class 9th Foundation","Class 10th Board Preparation","Class 11th Science","Class 12th Board + Competitive")) { c -> Card(Modifier.fillMaxWidth().padding(10.dp), shape=RoundedCornerShape(16.dp)) { Column(Modifier.padding(16.dp)) { Text(c,fontWeight=FontWeight.Bold,fontSize=17.sp); Text("Live + Recorded • Notes • Tests", color=Color.LightGray); Spacer(Modifier.height(10.dp)); OutlinedButton(onClick={}) { Text("View Course") } } } } } }
@Composable fun Tests() { LazyColumn { item { Header("Test Series","Practice & improve") }; items(listOf("Physics Chapter Test","Chemistry Chapter Test","Mathematics Practice Test","Biology Practice Test","Full Syllabus Mock Test")) { t -> ListItem(headlineContent={Text(t)}, supportingContent={Text("Start test when ready")}, leadingContent={Icon(Icons.Default.Assignment,null,tint=Gold)}) } } }
@Composable fun Profile() { Column(Modifier.fillMaxSize().padding(18.dp)) { Header("My Profile"); Spacer(Modifier.height(10.dp)); Card(Modifier.fillMaxWidth(), shape=RoundedCornerShape(18.dp)) { Column(Modifier.padding(18.dp)) { Text("Nitish Classes Student",fontSize=20.sp,fontWeight=FontWeight.Bold); Text("Classes 9th – 12th",color=Gold); Spacer(Modifier.height(16.dp)); Text("Contact / WhatsApp: 7561963942"); Text("Alternate: 9204378594") } }; Spacer(Modifier.height(16.dp)); Button(onClick={}, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Gold,contentColor=Black)) { Text("Login / Register") } } }
